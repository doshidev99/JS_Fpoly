const sum = (a, b) => a + b;
export { sum };
